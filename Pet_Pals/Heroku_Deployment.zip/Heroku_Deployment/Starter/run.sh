FLASK_APP=pet_pals/app.py flask run
